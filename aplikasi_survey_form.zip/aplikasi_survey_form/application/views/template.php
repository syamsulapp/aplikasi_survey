<?php 


include 'view_home';


<?
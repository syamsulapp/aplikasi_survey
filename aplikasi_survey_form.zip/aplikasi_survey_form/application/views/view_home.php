<?php


echo "selamat datang di aplikasi survey ini jangan lupa di isi sebaik baiknya ";

?>